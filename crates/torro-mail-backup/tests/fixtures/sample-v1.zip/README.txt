Torro Workplace mail backup v1
This ordinary ZIP is not encrypted.
Open mail/*.eml with an RFC 822 mail viewer; MIME attachments are inside each EML.
manifest.json describes folders, original dates, flags and completeness.
Its aliases list further folder entries, such as All Mail, whose bytes are already in the named EML.
SHA256SUMS lists the EMLs and the three metadata files, but not itself.
A complete status records a checked source inventory, not an atomic IMAP snapshot.
